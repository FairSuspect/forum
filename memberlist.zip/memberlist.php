<?php session_start() ;
$link = mysqli_connect ("localhost","root","","users");
       if (!$link) {
    echo "Ошибка: Невозможно установить соединение с MySQL." . PHP_EOL;
    echo "Код ошибки errno: " . mysqli_connect_errno() . PHP_EOL;
    echo "Текст ошибки error: " . mysqli_connect_error() . PHP_EOL;
    exit;
	   }?>
<html>
    <head>
	<meta charset="utf-8">
	<link rel = stylesheet href = "css\viewforum.css">
    <title>Список пользователей</title>
	
    </head>
<body>
<div class='quests'>
<h1 align = 'middle'> Список пользователей </h1>
<table align = 'center' style ='text-align: center;' width = '500px' border= '1px solid'>
<th> id </th>
<th> login </th>
<th> Date of registration </th>
<th> lvl </th>
<th> Action </th>
<?php
	$sql = "SELECT id, login, regDate, lvl FROM users";
	$result = mysqli_query($link,$sql);
	if($result)
	{
		$rows = mysqli_num_rows($result);
		for($i = 0; $i < $rows; ++$i)
		{
			echo "<tr>";
			$row = mysqli_fetch_row($result);
			for ($j = 0; $j < 4; $j++)
			{
				if($j == 1)
				{
					switch($row[3]){
					case 0: 
						$color='00C';
						break;
					case 1:
						$color='0C0';
						break;
					case 2:
						$color = 'C00';
						break;
					}
					echo "<td> <a style = 'color: #{$color}' href='viewprofile.php?u={$row[0]}'> {$row[1]} </a></td>";
					continue;
				}
				echo "<td> {$row[$j]} </td>";
			}
			if(isset($_SESSION['lvl']))
			{
				if ($row[3] < $_SESSION['lvl'])
				{
					echo "<td> <form action = 'accMng/action.php' method = 'POST'>
							<button class = 'dwn' name = 'delete' value = '{$row[0]}' > X </button>";
					
					if(isset($_POST['suspend']))
					{
						if($_POST['suspend'] == $row[1])
							echo "<form action = 'accMng/action.php' method = 'POST'>
									<select  style = 'color:white; background-color: red' name = 'time'> 								
									<option value = '10000'> 1 hour </option>
									<option value = '1000000'> 1 day </option>
									<option value = '7000000'> 1 week </option>
									<option value = '100000000'> 1 month </option>
									<option value = '10000000000'> 1 year </option>
								</select>
								Причина: <input type = 'text' name = 'reason'>
								<button value = '{$_POST['suspend']}' name='confirm'>✓</button></input> </form>";
						
					}
					if ($row[3] != 1 && $_SESSION['lvl']> 1)
						echo "<button class='upd' action = 'accMng/action.php' name = 'upgrade' value = '{$row[0]}'> + </button></form>";
					elseif ($row[3] == 1 && $_SESSION['lvl']>1)
						echo "<button class='dwn' action = 'accMng/action.php' name = 'downgrade' value = '{$row[0]}'> - </button></form>";
					echo "</form>";
					echo " <form action = 'memberlist.php?p=0' method = 'POST'><button  class='dwn' name = 'suspend' value = '{$row[1]}' > Ban </button></form></td>";
				}
				else 
				echo "<td> </td>";
			}
			else 
				echo "<td> </td>";
			echo "</tr>";
		}
	}

?>
</table>
<nav style='text-align:center'> <a href='../old.php'> Old </a>  |  |  <a href='../index.php'> Main </a> </nav>
<?php /*
if(isset($_POST['delete']))
{
	     
	$sql = "DELETE FROM `users` WHERE `users`.`id` = '{$_POST['delete']}' ";
	$result = mysqli_query($link,$sql) or dir("Ошибка: ".mysqli_error($link));
	header("Location: manage.php");
}
if(isset($_POST['upgrade']))
{
	     
	$sql = "UPDATE `users` SET `lvl`= '1' WHERE `users`.`id` = '{$_POST['upgrade']}' ";
	$result = mysqli_query($link,$sql) or dir("Ошибка: ".mysqli_error($link));
	header("Location: manage.php");
}
if(isset($_POST['downgrade']))
{
	     
	$sql = "UPDATE `users` SET `lvl`= '0' WHERE `users`.`id` = '{$_POST['downgrade']}' ";
	$result = mysqli_query($link,$sql) or dir("Ошибка: ".mysqli_error($link));
	header("Location: manage.php");
}
*/?>
</div>
</body>
</html>